Manipulating exposure and color channels
----------------------------------------
