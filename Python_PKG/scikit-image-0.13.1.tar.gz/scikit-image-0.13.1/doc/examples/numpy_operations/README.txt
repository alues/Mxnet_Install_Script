Operations on NumPy arrays
--------------------------
