.. include:: ../../TASKS.txt
.. include:: ../../.github/CONTRIBUTING.txt
