.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`viewer.widgets`
=============================
.. automodule:: skimage.viewer.widgets

.. currentmodule:: skimage.viewer.widgets
.. autosummary::


   skimage.viewer.widgets.BaseWidget
   skimage.viewer.widgets.Button
   skimage.viewer.widgets.CheckBox
   skimage.viewer.widgets.ComboBox
   skimage.viewer.widgets.OKCancelButtons
   skimage.viewer.widgets.SaveButtons
   skimage.viewer.widgets.Slider
   skimage.viewer.widgets.Text

    skimage.viewer.widgets.core
    skimage.viewer.widgets.history


:class:`BaseWidget`
-------------------


.. autoclass:: BaseWidget
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`Button`
---------------


.. autoclass:: Button
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`CheckBox`
-----------------


.. autoclass:: CheckBox
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`ComboBox`
-----------------


.. autoclass:: ComboBox
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`OKCancelButtons`
------------------------


.. autoclass:: OKCancelButtons
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`SaveButtons`
--------------------


.. autoclass:: SaveButtons
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`Slider`
---------------


.. autoclass:: Slider
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`Text`
-------------


.. autoclass:: Text
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__
