.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`viewer.viewers`
=============================
.. automodule:: skimage.viewer.viewers

.. currentmodule:: skimage.viewer.viewers
.. autosummary::


   skimage.viewer.viewers.CollectionViewer
   skimage.viewer.viewers.ImageViewer

    skimage.viewer.viewers.core


:class:`CollectionViewer`
-------------------------


.. autoclass:: CollectionViewer
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`ImageViewer`
--------------------


.. autoclass:: ImageViewer
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__
