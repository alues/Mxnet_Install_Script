.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`novice`
=====================
.. automodule:: skimage.novice

.. currentmodule:: skimage.novice
.. autosummary::

   skimage.novice.open

   skimage.novice.Picture


open
----

.. autofunction:: skimage.novice.open


:class:`Picture`
----------------


.. autoclass:: Picture
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__
