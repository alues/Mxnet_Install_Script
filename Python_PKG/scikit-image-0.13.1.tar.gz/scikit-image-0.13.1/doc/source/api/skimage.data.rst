.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`data`
===================
.. automodule:: skimage.data

.. currentmodule:: skimage.data
.. autosummary::

   skimage.data.astronaut
   skimage.data.binary_blobs
   skimage.data.camera
   skimage.data.checkerboard
   skimage.data.chelsea
   skimage.data.clock
   skimage.data.coffee
   skimage.data.coins
   skimage.data.expected_warnings
   skimage.data.horse
   skimage.data.hubble_deep_field
   skimage.data.img_as_bool
   skimage.data.immunohistochemistry
   skimage.data.imread
   skimage.data.load
   skimage.data.logo
   skimage.data.moon
   skimage.data.page
   skimage.data.rocket
   skimage.data.stereo_motorcycle
   skimage.data.text
   skimage.data.use_plugin


    skimage.data.np

astronaut
---------

.. autofunction:: skimage.data.astronaut

binary_blobs
------------

.. autofunction:: skimage.data.binary_blobs

camera
------

.. autofunction:: skimage.data.camera

checkerboard
------------

.. autofunction:: skimage.data.checkerboard

chelsea
-------

.. autofunction:: skimage.data.chelsea

clock
-----

.. autofunction:: skimage.data.clock

coffee
------

.. autofunction:: skimage.data.coffee

coins
-----

.. autofunction:: skimage.data.coins

expected_warnings
-----------------

.. autofunction:: skimage.data.expected_warnings

horse
-----

.. autofunction:: skimage.data.horse

hubble_deep_field
-----------------

.. autofunction:: skimage.data.hubble_deep_field

img_as_bool
-----------

.. autofunction:: skimage.data.img_as_bool

immunohistochemistry
--------------------

.. autofunction:: skimage.data.immunohistochemistry

imread
------

.. autofunction:: skimage.data.imread

load
----

.. autofunction:: skimage.data.load

logo
----

.. autofunction:: skimage.data.logo

moon
----

.. autofunction:: skimage.data.moon

page
----

.. autofunction:: skimage.data.page

rocket
------

.. autofunction:: skimage.data.rocket

stereo_motorcycle
-----------------

.. autofunction:: skimage.data.stereo_motorcycle

text
----

.. autofunction:: skimage.data.text

use_plugin
----------

.. autofunction:: skimage.data.use_plugin

