.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`external`
=======================
.. automodule:: skimage.external

.. currentmodule:: skimage.external
.. autosummary::



    skimage.external.tifffile

