.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`viewer`
=====================
.. automodule:: skimage.viewer

.. currentmodule:: skimage.viewer
.. autosummary::

   skimage.viewer.warn

   skimage.viewer.CollectionViewer
   skimage.viewer.ImageViewer

    skimage.viewer.canvastools
    skimage.viewer.plugins
    skimage.viewer.qt
    skimage.viewer.utils
    skimage.viewer.viewers
    skimage.viewer.widgets

warn
----

.. autofunction:: skimage.viewer.warn


:class:`CollectionViewer`
-------------------------


.. autoclass:: CollectionViewer
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`ImageViewer`
--------------------


.. autoclass:: ImageViewer
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__
