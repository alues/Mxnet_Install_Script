.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`future`
=====================
.. automodule:: skimage.future

.. currentmodule:: skimage.future
.. autosummary::



    skimage.future.graph

