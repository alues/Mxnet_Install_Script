.. AUTO-GENERATED FILE -- DO NOT EDIT!

API Reference for skimage |version|
===================================

Submodules
----------

- `skimage <skimage.html>`__

  - `color <skimage.color.html>`__

  - `data <skimage.data.html>`__

  - `draw <skimage.draw.html>`__

  - `exposure <skimage.exposure.html>`__

  - `external <skimage.external.html>`__

  - `feature <skimage.feature.html>`__

  - `filters <skimage.filters.html>`__

  - `future <skimage.future.html>`__

  - `graph <skimage.graph.html>`__

  - `io <skimage.io.html>`__

  - `measure <skimage.measure.html>`__

  - `morphology <skimage.morphology.html>`__

  - `novice <skimage.novice.html>`__

  - `restoration <skimage.restoration.html>`__

  - `segmentation <skimage.segmentation.html>`__

  - `transform <skimage.transform.html>`__

  - `util <skimage.util.html>`__

  - `viewer <skimage.viewer.html>`__

Submodule Contents
------------------

.. toctree::

   skimage
   skimage.color
   skimage.data
   skimage.draw
   skimage.exposure
   skimage.external
   skimage.external.tifffile
   skimage.feature
   skimage.filters
   skimage.filters.rank
   skimage.future
   skimage.future.graph
   skimage.graph
   skimage.io
   skimage.measure
   skimage.morphology
   skimage.novice
   skimage.restoration
   skimage.segmentation
   skimage.transform
   skimage.util
   skimage.viewer
   skimage.viewer.canvastools
   skimage.viewer.plugins
   skimage.viewer.utils
   skimage.viewer.viewers
   skimage.viewer.widgets
